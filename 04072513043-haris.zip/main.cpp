#include<iostream>
#include<forward_list>
#include <ctime>
#include<cstdlib>
#include<chrono>
#include<algorithm>
#include<list>
#include <vector>


long long calculatetime(std::chrono::high_resolution_clock::time_point start,
    std::chrono::high_resolution_clock::time_point end)
{
    auto duration = std::chrono::duration_cast<std::chrono::microseconds>(end - start);
    return duration.count();
}
void heapify(std::vector<int>& a, int size, int parent) {
    int biggest = parent;
    int left = 2 * parent + 1;
    int right = 2 * parent + 2;

    if (left < size && a[left] > a[biggest])
        biggest = left;
    if (right < size && a[right] > a[biggest])
        biggest = right;

    if (biggest != parent) {
        std::swap(a[parent], a[biggest]);
        heapify(a, size, biggest);
    }
}
void heapSort(std::vector<int>& a) {
    int size = a.size();
    for (int i = (size / 2) - 1; i >= 0; --i)
        heapify(a, size, i);
    for (int i = size - 1; i > 0; --i) {
        std::swap(a[0], a[i]);
        heapify(a, i, 0);
    }
}
void insertionSort(std::vector<int>& a) {
    int size = a.size();
    for (int i = 1; i < size; ++i) {
        int val = a[i];
        int j = i - 1;
        while (j >= 0 && a[j] > val) {
            a[j + 1] = a[j];
            j--;
        }
        a[j + 1] = val;
    }
}
int main() {
   
    std::forward_list <int> a, b, c, e, f, g; 

    std::srand(std::time(0));
    std::cout << "Insertion of A,B,C,E,F,G:" << std::endl;
    auto start = std::chrono::high_resolution_clock::now();
    for (int i = 1; i <= 1000; i++)
    {
        a.push_front(i);//vector
    }
    auto end = std::chrono::high_resolution_clock::now();
    std::cout << "a:" << calculatetime(start, end) << "micro seconds" << std::endl;


    start = std::chrono::high_resolution_clock::now();
    for (int i = 100000; i >= 1; i--)
    {
        b.push_front(i);
    }
    end = std::chrono::high_resolution_clock::now();
    std::cout << "b:" << calculatetime(start, end) << "micro seconds" << std::endl;


    start = std::chrono::high_resolution_clock::now();
    for (int i = 1; i <= 100000; i++) {
        c.push_front(std::rand() % 100000);
    }
    end = std::chrono::high_resolution_clock::now();

    std::cout << "c:" << calculatetime(start, end) << "micro seconds" << std::endl;

    start = std::chrono::high_resolution_clock::now();
    for (int i = 1; i <= 100000; i++)
    {
        e.push_front(i);//vector
    }
    end = std::chrono::high_resolution_clock::now();

    std::cout << "e:" << calculatetime(start, end) << "micro seconds" << std::endl;

    start = std::chrono::high_resolution_clock::now();
    for (int i = 100000; i >= 1; i--) {
        f.push_front(i);
    }
    end = std::chrono::high_resolution_clock::now();

    std::cout << "f:" << calculatetime(start, end) << "micro seconds" << std::endl;


    start = std::chrono::high_resolution_clock::now();
    for (int i = 1; i <= 100000; i++) {
        g.push_front(rand() % 100000);
    }
    end = std::chrono::high_resolution_clock::now();

    std::cout << "g:" << calculatetime(start, end) << "micro seconds" << std::endl;

    std::cout << "Sorting of A,B,C:" << std::endl;

    start = std::chrono::high_resolution_clock::now();
    a.sort();
    end = std::chrono::high_resolution_clock::now();

    std::cout << "a:" << calculatetime(start, end) << "micro seconds" << std::endl;

    start = std::chrono::high_resolution_clock::now();
    b.sort();
    end = std::chrono::high_resolution_clock::now();
    std::cout << "b:" << calculatetime(start, end) << "micro seconds" << std::endl;

    start = std::chrono::high_resolution_clock::now();
    c.sort();
    end = std::chrono::high_resolution_clock::now();

    std::cout << "c:" << calculatetime(start, end) << "micro seconds" << std::endl;

    std::cout << "Deleting odds from E,F,G:" << std::endl;
    start = std::chrono::high_resolution_clock::now();
    e.remove_if ( [](int v) {return v % 2 != 0; });
    end = std::chrono::high_resolution_clock::now();

    std::cout << "e:" << calculatetime(start, end) << "micro seconds" << std::endl;

    start = std::chrono::high_resolution_clock::now();
    f.remove_if([](int v) {return v % 2 != 0; });
    end = std::chrono::high_resolution_clock::now();

    std::cout << "f:" << calculatetime(start, end) << "micro seconds" << std::endl;

    start = std::chrono::high_resolution_clock::now();
    g.remove_if([](int v) {return v % 2 != 0; });
    end = std::chrono::high_resolution_clock::now();

    std::cout << "g:" << calculatetime(start, end) << "micro seconds" << std::endl;

    ///////////////////////////////////////////////////////////
   // */

   /* 
   list <int> a, b, c, e, f, g;
    // a=ascending, b=descending, c=random 

    srand(time(0));
    std::cout << "Insertion of A,B,C,E,F,G:" << std::endl;
    auto start = std::chrono::high_resolution_clock::now();
    for (int i = 1; i <= 100000; i++)
    {
        a.push_back(i);//vector
    }
    auto end = std::chrono::high_resolution_clock::now();
    std::cout << "a:" << calculatetime(start, end) << "micro seconds" << std::endl;


    start = std::chrono::high_resolution_clock::now();
    for (int i = 100000; i >= 1; i--)
    {
        b.push_back(i);
    }
    end = std::chrono::high_resolution_clock::now();
    std::cout << "b:" << calculatetime(start, end) << "micro seconds" << std::endl;


    start = std::chrono::high_resolution_clock::now();
    for (int i = 1; i <= 100000; i++) {
        c.push_back(rand() % 100000);
    }
    end = std::chrono::high_resolution_clock::now();
    std::cout << "c:" << calculatetime(start, end) << "micro seconds" << std::endl;

    start = std::chrono::high_resolution_clock::now();
    for (int i = 1; i <= 100000; i++)
    {
        e.push_back(i);
    }
    end = std::chrono::high_resolution_clock::now();
    std::cout << "e:" << calculatetime(start, end) << "micro seconds" << std::endl;

    start = std::chrono::high_resolution_clock::now();
    for (int i = 100000; i >= 1; i--) {
        f.push_back(i);
    }
    end = std::chrono::high_resolution_clock::now();
    std::cout << "f:" << calculatetime(start, end) << "micro seconds" << std::endl;


    start = std::chrono::high_resolution_clock::now();
    for (int i = 1; i <= 100000; i++) {
        g.push_back(rand() % 100000);
    }
    end = std::chrono::high_resolution_clock::now();
    std::cout << "g:" << calculatetime(start, end) << "micro seconds" << std::endl;

    std::cout << "Sorting of A,B,C:" << std::endl;
    start = std::chrono::high_resolution_clock::now();
    a.sort();
    end = std::chrono::high_resolution_clock::now();
    std::cout << "a:" << calculatetime(start, end) << "micro seconds" << std::endl;

    start = std::chrono::high_resolution_clock::now();
    b.sort();
    end = std::chrono::high_resolution_clock::now();
    std::cout << "b:" << calculatetime(start, end) << "micro seconds" << std::endl;

    start = std::chrono::high_resolution_clock::now();
    c.sort();
    end = std::chrono::high_resolution_clock::now();
    std::cout << "c:" << calculatetime(start, end) << "micro seconds" << std::endl;

    std::cout << "Deleting odds from E,F,G:" << std::endl;
    start = std::chrono::high_resolution_clock::now();
    e.remove_if([](int v) {return v % 2 != 0; });
    end = std::chrono::high_resolution_clock::now();
    std::cout << "e:" << calculatetime(start, end) << "micro seconds" << std::endl;

    start = std::chrono::high_resolution_clock::now();
    f.remove_if([](int v) {return v % 2 != 0; });
    end = std::chrono::high_resolution_clock::now();
    std::cout << "f:" << calculatetime(start, end) << "micro seconds" << std::endl;

    start = std::chrono::high_resolution_clock::now();
    g.remove_if([](int v) {return v % 2 != 0; });
    end = std::chrono::high_resolution_clock::now();
    std::cout << "g:" << calculatetime(start, end) << "micro seconds" << std::endl;
   // */
    /////////////////////////////////////////////////////////////////////

    /*std::vector<int> a, b, c, e, f, g;
    srand(time(0));
    std::cout << "Insertion of A,B,C,E,F,G:" << std::endl;
    auto start = std::chrono::high_resolution_clock::now();
    for (int i = 1; i <= 1000; i++)
    {
        a.push_back(i);//vector
    }
    auto end = std::chrono::high_resolution_clock::now();
    std::cout << "a:" << calculatetime(start, end) << "micro seconds" << std::endl;


    start = std::chrono::high_resolution_clock::now();
    for (int i = 100000; i >= 1; i--)
    {
        b.push_back(i);
    }
    end = std::chrono::high_resolution_clock::now();
    std::cout << "b:" << calculatetime(start, end) << "micro seconds" << std::endl;


    start = std::chrono::high_resolution_clock::now();
    for (int i = 1; i <= 100000; i++) {
        c.push_back(rand() % 100000);
    }
    end = std::chrono::high_resolution_clock::now();
    std::cout << "c:" << calculatetime(start, end) << "micro seconds" << std::endl;

    start = std::chrono::high_resolution_clock::now();
    for (int i = 1; i <= 100000; i++)
    {
        e.push_back(i);
    }
    end = std::chrono::high_resolution_clock::now();
    std::cout << "e:" << calculatetime(start, end) << "micro seconds" << std::endl;

    start = std::chrono::high_resolution_clock::now();
    for (int i = 100000; i >= 1; i--) {
        f.push_back(i);
    }
    end = std::chrono::high_resolution_clock::now();
    std::cout << "f:" << calculatetime(start, end) << "micro seconds" << std::endl;


    start = std::chrono::high_resolution_clock::now();
    for (int i = 1; i <= 100000; i++) {
        g.push_back(rand() % 100000);
    }
    end = std::chrono::high_resolution_clock::now();
    std::cout << "g:" << calculatetime(start, end) << "micro seconds" << std::endl;

    std::cout << "Sorting of A,B,C:" << std::endl;
    start = std::chrono::high_resolution_clock::now();
    std::sort(a.begin(),a.end());
    end = std::chrono::high_resolution_clock::now();

    std::cout << "a:" << calculatetime(start, end) << "micro seconds" << std::endl;

    start = std::chrono::high_resolution_clock::now();
    std::sort(b.begin(), b.end());
    end = std::chrono::high_resolution_clock::now();

    std::cout << "b:" << calculatetime(start, end) << "micro seconds" << std::endl;

    start = std::chrono::high_resolution_clock::now();
    std::sort(c.begin(), c.end());
    end = std::chrono::high_resolution_clock::now();
    std::cout << "c:" << calculatetime(start, end) << "micro seconds" << std::endl;

    std::cout << "Deleting odds from E,F,G:" << std::endl;
    start = std::chrono::high_resolution_clock::now();
    std::remove_if(e.begin(), e.end(), [](int v) {return v % 2 != 0; });
    end = std::chrono::high_resolution_clock::now();

    std::cout << "e:" << calculatetime(start, end) << "micro seconds" << std::endl;

    start = std::chrono::high_resolution_clock::now();
    std::remove_if(f.begin(), f.end(), [](int v) {return v % 2 != 0; });
    end = std::chrono::high_resolution_clock::now();
    std::cout << "f:" << calculatetime(start, end) << "micro seconds" << std::endl;

    start = std::chrono::high_resolution_clock::now();
    std:: remove_if(g.begin(), g.end(), [](int v) {return v % 2 != 0; });
    end = std::chrono::high_resolution_clock::now();

    std::cout << "g:" << calculatetime(start, end) << "micro seconds" << std::endl;
    */

  // std::vector<int> a, b, c, e, f, g;
   /*
   srand(time(0));
   std::cout << "Insertion of A,B,C,E,F,G:" << std::endl;
   auto start = std::chrono::high_resolution_clock::now();
   for (int i = 1; i <= 100000; i++)
   {
       a.push_back(i);//vector
   }
   auto end = std::chrono::high_resolution_clock::now();
   std::cout << "a:" << calculatetime(start, end) << "micro seconds" << std::endl;


   start = std::chrono::high_resolution_clock::now();
   for (int i = 100000; i >= 1; i--)
   {
       b.push_back(i);
   }
   end = std::chrono::high_resolution_clock::now();
   std::cout << "b:" << calculatetime(start, end) << "micro seconds" << std::endl;


   start = std::chrono::high_resolution_clock::now();
   for (int i = 1; i <= 100000; i++) {
       c.push_back(rand() % 100000);
   }
   end = std::chrono::high_resolution_clock::now();
   std::cout << "c:" << calculatetime(start, end) << "micro seconds" << std::endl;

   start = std::chrono::high_resolution_clock::now();
   for (int i = 1; i <= 100000; i++)
   {
       e.push_back(i);
   }
   end = std::chrono::high_resolution_clock::now();
   std::cout << "e:" << calculatetime(start, end) << "micro seconds" << std::endl;

  auto start  = std::chrono::high_resolution_clock::now();
   for (int i = 100000; i >= 1; i--) {
       f.push_back(i);
   }
  auto end = std::chrono::high_resolution_clock::now();
   std::cout << "f:" << calculatetime(start, end) << "micro seconds" << std::endl;


   start = std::chrono::high_resolution_clock::now();
   for (int i = 1; i <= 100000; i++) {
       g.push_back(rand() % 100000);
   }
   end = std::chrono::high_resolution_clock::now();
   std::cout << "g:" << calculatetime(start, end) << "micro seconds" << std::endl;
   /*
   std::cout << "Heap Sorting of A,B,C:" << std::endl;
    start = std::chrono::high_resolution_clock::now();
    heapSort(a);
    end = std::chrono::high_resolution_clock::now();

    std::cout << "a:" << calculatetime(start, end) << "micro seconds" << std::endl;

    start = std::chrono::high_resolution_clock::now();
    heapSort(b);
    end = std::chrono::high_resolution_clock::now();

    std::cout << "b:" << calculatetime(start, end) << "micro seconds" << std::endl;

    start = std::chrono::high_resolution_clock::now();
    heapSort(c);
    end = std::chrono::high_resolution_clock::now();

    std::cout << "c:" << calculatetime(start, end) << "micro seconds" << std::endl;
     
    std::cout << "Insert Sorting of E,F,G:" << std::endl;
    start = std::chrono::high_resolution_clock::now();
    insertionSort(e);
    end = std::chrono::high_resolution_clock::now();

    std::cout << "e:" << calculatetime(start, end) << "micro seconds" << std::endl;
   
    start = std::chrono::high_resolution_clock::now();
    insertionSort(f);
    end = std::chrono::high_resolution_clock::now();

    std::cout << "f:" << calculatetime(start, end) << "micro seconds" << std::endl;

    start = std::chrono::high_resolution_clock::now();
    insertionSort(g);
    end = std::chrono::high_resolution_clock::now();

    std::cout << "g:" << calculatetime(start, end) << "micro seconds" << std::insertion of;
     */
}





