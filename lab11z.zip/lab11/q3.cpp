#include<iostream>
using namespace std;
bool ispalindrome(const string& str, int left, int right)
{
    if(left>=right)
        return true;

    if(str[left]!=str[right])
        return false;

    return ispalindrome(str, ++left, --right);
}
int main(){
    string str="level";
    bool t=ispalindrome(str, 0, 4);

    if(t){
        cout<<"it is a palindrome";
    }
    else
    cout<<"not a palindrome";
return 0;
}