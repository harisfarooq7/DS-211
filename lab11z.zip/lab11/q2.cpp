#include<iostream>
using namespace std;
int sum(int n){
    if(n!= 0){
        return n%10+sum(n / 10);
    }
    else 
    return 0;
}
int main(){
    int a=5724;

    int r=sum(a);
    cout<<r;

return 0;
}