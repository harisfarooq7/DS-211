#include<iostream>
using namespace std;

int sum(int n){
    if(n>0)
    return n+sum(n-1);

    else
    return 0;
}
int main(){
    int a=5;

    int r=sum(5);

    cout<<r;


return 0;
}